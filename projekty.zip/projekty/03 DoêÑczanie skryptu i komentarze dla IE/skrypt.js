alert("to jest tekst wyświetlony przez skrypt")
